<?php

header ( 'Access-Control-Allow-Origin:  *' ) ;
header ( 'Access-Control-Allow-Methods:  POST, GET, OPTIONS, PUT, DELETE' ) ;
header ( 'Access-Control-Allow-Headers:  Content-Type, X-Auth-Token, Origin, Authorization, auth-token, user-type' ) ;
header ( 'Access-Control-Expose-Headers:  App-Content-Full-Count' ) ;

Route::group ( [
	'prefix' => ''
	] , function()
{
	$routeFilesPath	 = base_path ( 'routes/api/*.php' ) ;
	$routeFiles		 = glob ( $routeFilesPath ) ;

	foreach ( $routeFiles as $routeFile )
	{
		require_once $routeFile ;
	}
} ) ;