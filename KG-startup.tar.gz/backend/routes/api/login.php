<?php

use App\Constants\UserTypeConstants ;

Route::group ( [
	'prefix' => 'auth/admins/'
	] , function()
{
	Route::post ( 'login' , [
		'as'	 => 'auth.admins.login' ,
		'uses'	 => 'Auth\AdminsController@login'
	] ) ;
	
	Route::get ( 'validate-session' , [
		'as' => 'auth.admins.validate-session' ,
		'uses' => 'Auth\AdminsController@validateSession' ,
		'middleware' => 'auth:' . UserTypeConstants::Admin ,
	] ) ;
} ) ;
