<?php

namespace App\Constants ;

class UserTypeConstants
{

	const Admin = 'admin' ;

}
