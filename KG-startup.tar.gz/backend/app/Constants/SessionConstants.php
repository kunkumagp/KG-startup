<?php

namespace App\Constants ;

class SessionConstants
{

	const UserType = 'user_type' ;
	const UserId	 = 'user_id' ;

}
