<?php

namespace App\Validators\Constants ;

class ErrorConstants
{

	const NumberTooLarge = 'number_too_large' ;
	const NumberTooSmall = 'number_too_small' ;
	const NumberOutOfRange = 'number_out_of_range' ;
	const StringDatabaseEntryNotFound = 'string_database_entry_not_found' ;
	const StringDuplicate = 'string_duplicate' ;
	const StringEmpty = 'string_empty' ;
	const StringInvalid = 'string_invalid' ;
	const StringInvalidFormat = 'string_invalid_format' ;
	const StringLengthOutOfRange = 'string_length_out_of_range' ;
	const StringNotConfirmed = 'string_not_confirmed' ;

}
