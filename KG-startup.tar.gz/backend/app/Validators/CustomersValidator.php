<?php

namespace App\Validators;

use App\Validators\Constants\ErrorConstants;
use App\Validators\Exceptions\InvalidInputException;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Validation\Validator;

class CustomersValidator {

    use ValidatesRequests;

    public function create(Request $request) {
        $rules = [
            'customerName' => [
                'required'
            ],
            'customerName' => [
                'unique:customers,name'
            ],
                ];

        $messages = [
            'name.required' => ErrorConstants::StringEmpty,
            'customerName.unique' => ErrorConstants::StringDuplicate,
                ];

        $this->validate($request, $rules, $messages);
    }

    public function update(Request $request, $id) {
        $rules = [
            'name' => [
                'unique:products,name,' . $id
            ],
            'category_id' => [
                'required',
            ],
                ];

        $messages = [
            'name.unique' => ErrorConstants::StringDuplicate,
            'category_id.required' => ErrorConstants::StringEmpty,
                ];

        $this->validate($request, $rules, $messages);
    }

    protected function throwValidationException(Request $req, Validator $val) {
        $errors = $val->errors()->toArray();
        throw new InvalidInputException($errors);
    }

}
