<?php

namespace App ;

use Carbon\Carbon ;
use Illuminate\Database\Eloquent\ModelNotFoundException ;
use Illuminate\Support\Collection ;
use Illuminate\Database\Eloquent\Model ;

class UserAuthSession extends Model
{

	protected $dates = ['expiring_time' ] ;

	public function admin ()
	{
		return $this -> belongsTo (User::class ) ;
	}

	public function createAuthToken ()
	{
		$this -> expiring_time	 = (new Carbon() ) -> addHours ( 24 ) ;
		$this -> token			 = \Hash::make ( $this -> expiring_time ) ;

		return $this ;
	}

	public function extendExpiringTime ( $hours = 24 )
	{
		$extendedpiringTime		 = Carbon::now () -> addHours ( $hours ) ;
		$this -> expiring_time	 = $extendedpiringTime ;

		$this -> save () ;
	}

	public function isValid ()
	{
		$now = Carbon::now () ;

		return $now -> lt ( $this -> expiring_time ) ;
	}

}