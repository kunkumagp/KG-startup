<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function authSessions ()
	{
		return $this -> hasMany ( UserAuthSession::class ) ;
	}

	public function createAuthSession ()
	{
		$authSession = new UserAuthSession() ;

		$authSession -> createAuthToken () ;

		$this
			-> authSessions ()
			-> save ( $authSession ) ;

		return $authSession ;
	}

	public function deleteExpiredAuthSessions ()
	{
		$this -> authSessions -> each ( function(UserAuthSession $authSession)
		{
			if ( ! $authSession -> isValid () )
			{
				$authSession -> delete () ;
			}
		} ) ;
	}
}
