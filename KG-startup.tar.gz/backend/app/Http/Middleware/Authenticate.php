<?php

namespace App\Http\Middleware ;

use App\UserAuthSession ;
use App\Constants\SessionConstants ;
use App\Constants\UserTypeConstants ;
use App\CaretakerAuthSession ;
use Carbon\Carbon ;
use Closure ;
use Illuminate\Database\Eloquent\ModelNotFoundException ;
use Illuminate\Support\Facades\Session ;
use Illuminate\Http\Request ;

class Authenticate
{

	public function handle ( Request $request , Closure $next , ...$allowedUserTypes )
	{
		$authToken = $request -> header ( 'auth-token' ) ;
		$userType = $request -> header ( 'user-type' ) ;

		if (
			count ( $allowedUserTypes ) > 0 &&
			( ! in_array ( $userType , $allowedUserTypes ) )
		)
		{
			return response ( NULL , 403 ) ;
		}

		try
		{
			switch ( $userType )
			{
				case UserTypeConstants::Admin:
					$this -> handleAdmin ( $authToken , $request ) ;
					break ;

				case UserTypeConstants::Caretaker:
					$this -> handleCaretaker ( $authToken , $request ) ;
					break ;
			}
		} catch ( ModelNotFoundException $ex )
		{
			return response ( NULL , 401 ) ;
		}

		return $next ( $request ) ;
	}

	private function handleAdmin ( $authToken , Request $request )
	{
		$authSession = UserAuthSession::
			where ( 'token' , '=' , $authToken )
			-> firstOrFail () ;

		$admin = $authSession -> admin ;

		//$admin -> deleteExpiredAuthSessions () ;

//		if ( ! $authSession -> isValid () )
//		{
//			throw new ModelNotFoundException() ;
//		}
//
//		$this -> setLoginSession ( $request , UserTypeConstants::Admin , $admin -> id ) ;
//
//		$authSession -> extendExpiringTime () ;
	}

	private function handleCaretaker ( $authToken , Request $request )
	{
		$authSession = CaretakerAuthSession::
			where ( 'token' , '=' , $authToken )
			-> firstOrFail () ;

		$caretaker = $authSession -> caretaker ;

		$caretaker -> deleteExpiredAuthSessions () ;

		if ( ! $authSession -> isValid () )
		{
			throw new ModelNotFoundException() ;
		}

		$this -> setLoginSession ( $request , UserTypeConstants::Caretaker , $caretaker -> id ) ;

		$authSession -> extendExpiringTime () ;
	}

	private function setLoginSession ( Request $request , $userType , $userId = NULL )
	{
		Session:: put ( SessionConstants::UserType , $userType ) ;
		Session:: put ( SessionConstants::UserId , $userId ) ;
	}

}
