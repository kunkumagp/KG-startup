define([
	'app'
], function (
	app
	) {
	app
		.factory('InvalidInputException', [
			function (
				) {

				return function InvalidInputException(message) {
					this.message = message;
				};

			}
		]);
});