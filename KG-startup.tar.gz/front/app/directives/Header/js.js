define([
	'app',
	'handlers/AuthHandler',
	'services/AppStorage'
], function (
	app
	) {
	app.directive('header', function () {
		return {
			restrict: 'A',
			templateUrl: 'app/directives/Header/html.html',
			controller: [
				'$rootScope',
				'$scope',
				'AuthHandler',
				'AppStorage',
				function (
					$rootScope,
					$scope,
					AuthHandler,
					AppStorage
					) {

					$rootScope.loggedUser = AppStorage.getObject('admin');

					$scope.tryLogout = function ()
					{
						AuthHandler.logout('login');
						$rootScope.loggedUser = {};
					}

				}]
		};
	});
});