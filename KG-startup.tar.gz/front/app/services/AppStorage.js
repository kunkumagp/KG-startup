define(['app'], function (app) {
	app
		.factory('AppStorage', [
			function (
				) {
				return {
					setObject: function (key, value) {
						return localStorage.setItem(key, JSON.stringify(value));
					},
					getObject: function (key) {
						var object = localStorage.getItem(key);
						return JSON.parse(object);
					},
					setItem: function (key, value) {
						return localStorage.setItem(key, value);
					},
					getItem: function (key) {
						var item = localStorage.getItem(key);
						return item;
					},
					removeItem: function (key) {
						return localStorage.removeItem(key);
					},
					removeObject: function (key) {
						this.removeItem(key);
					},
					allClear: function () {
						localStorage.clear();
					},
					updateLocalStorage: function (newDetails) {
						var oldUser = this.getObject('admin');
						oldUser.username = newDetails.username;
						oldUser.first_name = newDetails.first_name;
						oldUser.last_name = newDetails.last_name;
						this.removeItem('admin');
						this.setObject('admin', oldUser);
					}
				};
			}
		]);
});

