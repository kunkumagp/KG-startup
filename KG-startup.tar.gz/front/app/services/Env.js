define([
	'app'
], function (app) {
	app.factory('Env', [
		'$http',
		'$q',
		function (
			$http,
			$q
			) {
			function loadEnvJson() {
				var d = $q.defer();

				$http.get('/env.json')
					.then(function (r) {
						var json = r.data;

						d.resolve(json);
					});

				return d.promise;
			}

			return {
				get: function (key) {
					var d = $q.defer();

					loadEnvJson()
						.then(function (json) {
							d.resolve(json[key]);
						});

					return d.promise;
				}
			};
		}
	]);
});
