define([
	'app',
	'services/AppStorage',
	'services/Env'
], function (app) {
	app
		.factory('csmsAPI', [
			'$http',
			'$stateParams',
			'$httpParamSerializerJQLike',
			'$q',
			'AppStorage',
			'Env',
			function (
				$http,
				$stateParams,
				$httpParamSerializerJQLike,
				$q,
				AppStorage,
				Env
				) {
				var apiUrlBase = null;
				function setApiUrl() {
					var d = $q.defer();
					Env.get('apiUrlBase')
						.then(function (r) {
							apiUrlBase = r;
							d.resolve();
						});
					return d.promise;
				}

				function setCustomHeader(userType) {
					var authToken = (AppStorage.getObject('admin') === null) ? null : AppStorage.getObject('admin').auth_token;
					$http.defaults.headers.common['auth-token'] = authToken;
					if (typeof userType != "undefined")
					{
						$http.defaults.headers.common['user-type'] = userType;
					}
					$http.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded';
				}

				return {
					auth: {
						login: function (loginUser) {
							setCustomHeader('admin');
							return setApiUrl().then(function () {
								return $http.post(
									apiUrlBase + 'auth/admins/login', {
										username: loginUser.username,
										password: loginUser.password
									}
								);
							});
						},
						validate: function () {
							setCustomHeader('admin');
							return setApiUrl()
								.then(function () {
									return $http
										.get(
											apiUrlBase
											+ 'auth/admins/validate-session'
											);
								});
						}
					}
				};
			}
		]);
});
