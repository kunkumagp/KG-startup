require.config({
	paths: {
		'angular': '../vendor/angular/angular.min',
		'angular-route': '../vendor/angular-route/angular-route.min',
		'ui-router': '../vendor/ui-router/release/angular-ui-router.min',
		'ui-bootstrap': '../vendor/angular-bootstrap/ui-bootstrap-tpls.min',
		'angular-validation': '../vendor/angular-validation/dist/angular-validation.min',
		'angular-validation-rule': '../vendor/angular-validation/dist/angular-validation-rule.min',
		'toastr':'../vendor/angular-toastr/dist/angular-toastr.tpls.min',
		'sweetAlert':'../vendor/sweetalert/dist/sweetalert.min'
	},
	shim: {
		'angular-validation': {
			deps: [
				'angular'
			]
		},
		'angular-validation-rule': {
			deps: [
				'angular',
				'angular-validation'
			]
		},
		'angular': {
			exports: 'angular'
		},
		'angular-route': {
			deps: [
				'angular'
			]
		},
		'ui-router': {
			deps: [
				'angular-route'
			]
		},
		'app': {
			deps: [
				'angular',
				'angular-route',
				'ui-router',
				'ui-bootstrap',
				'angular-validation',
				'angular-validation-rule',
				'toastr',
				'sweetAlert'
			]
		}
	}
});

require([
	'angular',
	'bootstrap'
], function (
		angular
		) {
	angular.bootstrap(document, ['app']);
});