define([
	'app',
	'directives/Header/js',
	'handlers/AuthHandler',
	'handlers/RentRecordsHandler',
	'handlers/ValidationHandler',
	'models/RentRecordModel'
], function (
	app
	) {
	app.controller('RentRecordsController', [
		'$sce',
		'$scope',
		'toastr',
		'$rootScope',
		'AuthHandler',
		'RentRecordsHandler',
		'ValidationHandler',
		'toastr',
		'RentRecordModel',
		'$uibModal',
		function (
			$sce,
			$scope,
			toastr,
			$rootScope,
			AuthHandler,
			RentRecordsHandler,
			ValidationHandler,
			toastr,
			RentRecordModel,
			$uibModal
			) {
			$rootScope.pageTitle = "Rent Records";

			AuthHandler.logoutIfSessionExpired();

			init()


			function init()
			{
				startTime();
				getAllItems();
			}


			function getAllItems()
			{
				RentRecordsHandler.all()
					.then(function (r) {
						$scope.items = r;
					})
					.catch(function (r) {
//						console.log(r);
//						toastr.error('Something is wrong', 'Error');
					});
			}
			function clearForm()
			{
				$scope.rentRequestStructure = new RentRecordModel();
				$scope.errorsList = $sce.trustAsHtml("");
			}
			
			$scope.addRentRecord = function (formData) {
				var rentRecord = angular.copy(new RentRecordModel());
				rentRecord.customerName = formData.customerName;
				rentRecord.customerPhone = formData.customerPhone;
				rentRecord.itemId = formData.itemId;	
				rentRecord.create()
					.then(function (r) {
						getAllItems();
						clearForm();
						toastr.success('Site added successfully', 'Added');
					})
					.catch(function (r) {
						console.log(r);
						var errors = {
							"customerName": {
								'string_duplicate': "Customer already available.",
								'string_empty': "Please enter Customer name."
							}
						};
						$scope.errorsList = $sce.trustAsHtml(ValidationHandler.handleAPIValidation(r, errors));
						toastr.error('Something is wrong', 'Error');
					});
			}

			function startTime() {
				var today = new Date();
				var Y = today.getFullYear();
				var M = today.getMonth();
				var D = today.getDay();
				var h = today.getHours();
				var m = today.getMinutes();
				var s = today.getSeconds();
				m = checkTime(m);
				s = checkTime(s);
				document.getElementById('txt').innerHTML =
					Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
				var t = setTimeout(startTime, 500);
			}
			function checkTime(i) {
				if (i < 10) {
					i = "0" + i
				}
				;  // add zero in front of numbers < 10
				return i;
			}


		}
	]);
});