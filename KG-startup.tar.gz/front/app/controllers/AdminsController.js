define([
	'app',
	'app',
	'directives/Header/js',
	'handlers/AdminsHandler',
	'handlers/AuthHandler',
	'handlers/ValidationHandler',
	'models/AdminModel'
], function (
	app
	) {
	app.controller('AdminsController', [
		'$sce',
		'$scope',
		'toastr',
		'$rootScope',
		'AdminsHandler',
		'AuthHandler',
		'ValidationHandler',
		'AdminModel',
		function (
			$sce,
			$scope,
			toastr,
			$rootScope,
			AdminsHandler,
			AuthHandler,
			ValidationHandler,
			AdminModel
			) {
			AuthHandler.logoutIfSessionExpired();

			$rootScope.pageTitle = "Admins";
			$scope.isAddMode = true;
			$scope.adminStructure = new AdminModel();

			init();

			function init()
			{
				getAllAdmins();
			}

			function getAllAdmins()
			{
				AdminsHandler.all()
					.then(function (r) {
						$scope.admins = r;
					})
					.catch(function (r) {
						console.log(r);
						toastr.error('Something is wrong', 'Error');
					});
			}

			function clearAdminAddUpdateForm()
			{
				$scope.adminStructure = new AdminModel();
				$scope.errorsList = $sce.trustAsHtml("");
			}

			$scope.addNewAdmin = function (admin) {
				admin.create()
					.then(function (r) {
						getAllAdmins();
						clearAdminAddUpdateForm();
						toastr.success('Admin added successfully', 'Added');
					})
					.catch(function (r) {
						console.log(r);
						var errors = {
							"first_name": {
								'string_empty': "Please enter admin first name."
							},
							"last_name": {
								'string_empty': "Please enter admin last name."
							},
							"username": {
								'string_duplicate': "Admin already available.",
								'string_empty': "Please enter admin username."
							},
							"password": {
								'string_empty': "Please enter admin password.",
								'string_not_confirmed': "Password does not match the confirm password."
							}
						};
						$scope.errorsList = $sce.trustAsHtml(ValidationHandler.handleAPIValidation(r, errors));

						toastr.error('Something is wrong', 'Error');
					});
			}

			$scope.removeAdmin = function (admin)
			{
				swal({
					title: "Are you sure?",
					text: "This will remove '" + admin.first_name + "' .",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes, remove it!",
					closeOnConfirm: true
				},
					function () {
						admin.remove()
							.then(function (r) {
								getAllAdmins();
								toastr.success('Admin removed successfully', 'Removed');
							})
							.catch(function (r) {
								console.log(r);
								toastr.error('Something is wrong', 'Error');
							});
					});
			}
		}
	]);
});
