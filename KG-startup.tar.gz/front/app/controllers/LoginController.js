define([
	'app',
	'models/AdminModel',
	'exceptions/InvalidInputException',
	'handlers/AuthHandler',
	'services/AppStorage'
], function (
	app
	) {
	app.controller('LoginController',
		[
			'$rootScope',
			'$scope',
			'$sce',
			'$state',
			'AdminModel',
			'InvalidInputException',
			'AuthHandler',
			'AppStorage',
			function (
				$rootScope,
				$scope,
				$sce,
				$state,
				AdminModel,
				InvalidInputException,
				AuthHandler,
				AppStorage
				) {
				AuthHandler.redirectIfAuthenticated('home');

				$rootScope.pageTitle = 'Log In';

				$scope.tryLogin = function (credentials) {
					try {
						if (credentials === undefined) {
							throw new InvalidInputException('Please enter your credentials.');
						}

						var admin = new AdminModel();
						admin.username = credentials.username;
						admin.password = credentials.password;

						var pAdminLogin = admin.login();

						pAdminLogin.then(function (r) {
							admin.setLogged();
							$state.go('home');
						}, function (r) {
							$scope.errorsList = $sce.trustAsHtml("<ul class='list-group'><li  class='text-center list-group-item list-group-item-danger'>Invalid Credentials</li></ul>");
						});
					} catch (ex) {
						if (ex instanceof InvalidInputException) {
							console.log(ex.message);
						} else {
							throw ex;
						}
					}
				};
			}
		]);
});
