define([
	'app',
	'directives/Header/js',
	'handlers/AuthHandler'
], function (
	app
	) {
	app.controller('HomeController', [
		'$scope',
		'$rootScope',
		'AuthHandler',
		function (
			$scope,
			$rootScope,
			AuthHandler
			) {

			AuthHandler.logoutIfSessionExpired();

			$rootScope.pageTitle = "Home";
			

		}
	]);
});