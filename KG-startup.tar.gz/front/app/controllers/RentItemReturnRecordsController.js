define([
	'app',
	'directives/Header/js',
	'handlers/AuthHandler',
	'handlers/RentItemReturnRecordsHandler',
	'handlers/CustomerHandler',
	'handlers/ValidationHandler',
	'models/RentItemReturnRecordModel'
], function (
	app
	) {
	app.controller('RentItemReturnRecordsController', [
		'$sce',
		'$scope',
		'toastr',
		'$rootScope',
		'AuthHandler',
		'RentItemReturnRecordsHandler',
		'CustomerHandler',
		'ValidationHandler',
		'toastr',
		'RentItemReturnRecordModel',
		'$uibModal',
		function (
			$sce,
			$scope,
			toastr,
			$rootScope,
			AuthHandler,
			RentItemReturnRecordsHandler,
			CustomerHandler,
			ValidationHandler,
			toastr,
			RentItemReturnRecordModel,
			$uibModal
			) {
			$rootScope.pageTitle = "Rent Item Return Records";
			AuthHandler.logoutIfSessionExpired();
			init()


			function init()
			{
				startTime();
				getAllcustomers();
			}


			function getAllcustomers()
			{
				CustomerHandler.all()
					.then(function (r) {
						r[0] = {id: '', name: 'Select Customer'};
						$scope.customerStructure = "";
						$scope.records = "";
						$scope.btn = " disabled";
						$scope.customers = r;
					})
					.catch(function (r) {
						console.log(r);
						toastr.error('Something is wrong', 'Error');
					});
			}

			function clearForm()
			{
				$scope.rentItemReturnRecordStructure = new RentItemReturnRecordModel();
				$scope.errorsList = $sce.trustAsHtml("");
			}
			function clearForm2()
			{
				$scope.rentItemReturnRecordStructure = new RentItemReturnRecordModel();
				$scope.customerlist = new RentItemReturnRecordModel();
				$scope.errorsList = $sce.trustAsHtml("");
			}

			$scope.calculation = function (customer_id) {
				RentItemReturnRecordsHandler.calculation(customer_id)
					.then(function (r) {
						$scope.records = r;
					})
					.catch(function (r) {
						console.log(r);
						toastr.error('Please Select a Customer', 'Error');
						init();
					});
			}



			$scope.customerSearch = function (formData) {
				RentItemReturnRecordsHandler.one(formData.customer_id)
					.then(function (r) {
						clearForm();
						$scope.records = r;
						$scope.btn = "";
						$scope.total = 0;
					})
					.catch(function (r) {
						console.log(r);
						toastr.error('Please Select a Customer', 'Error');
						init();
					});
			}

			$scope.totalCalculate = function (price,id) {
				var lfckv = document.getElementById("returnId_"+id).checked;
				if (lfckv === true) {
					$scope.total += price;
				} else if (lfckv === false) {
					$scope.total -= price;
				}
			}
			$scope.returned = function (formData) {
				var rentReturnRecord = angular.copy(new RentItemReturnRecordModel());
				rentReturnRecord.returnId = formData.returnId;
				rentReturnRecord.update()
					.then(function (r) {
						clearForm2();
						init();
						toastr.success('Item Returned successfully', 'Added');
					})
					.catch(function (r) {
						console.log(r);
						toastr.error('Something is wrong', 'Error');
					});
			};
			function startTime() {
				var today = new Date();
				var Y = today.getFullYear();
				var M = today.getMonth();
				var D = today.getDay();
				var h = today.getHours();
				var m = today.getMinutes();
				var s = today.getSeconds();
				m = checkTime(m);
				s = checkTime(s);
				document.getElementById('txt').innerHTML =
					Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
				var t = setTimeout(startTime, 500);
			}
			function checkTime(i) {
				if (i < 10) {
					i = "0" + i
				}
				; // add zero in front of numbers < 10
				return i;
			}
		}
	]);
});