define([
	'app',
	'handlers/AuthHandler',
	'handlers/RentRecordsHandler',
	'services/AppStorage'
], function (
	app
	) {
	app
		.factory('RentRecordModel', [
			'$q',
			'$injector',
			'AuthHandler',
			'AppStorage',
			function (
				$q,
				$injector,
				AuthHandler,
				AppStorage
				) {

				var one = function () {
					var RentRecordsHandler = $injector.get('RentRecordsHandler');

					var d = $q.defer();

					RentRecordsHandler
						.one(this)
						.then(function (a) {
							d.resolve(a);
						}, function (a) {
							d.reject(a);
						});

					return d.promise;
				};
				var create = function () {
					var RentRecordsHandler = $injector.get('RentRecordsHandler');

					var d = $q.defer();
					RentRecordsHandler
						.create(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};

				var struct = {
					id: null,
					in_draft: null,
					created_at: null,
					one: one,
					create: create
				};

				return function () {
					return angular.extend({}, struct);
				};
			}
		]);
});
