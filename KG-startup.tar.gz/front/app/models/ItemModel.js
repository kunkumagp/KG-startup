define([
	'app',
	'handlers/ItemsHandler'
], function (
	app
	) {
	app.factory('ItemModel', [
		'$injector',
		'$q',
		function (
			$injector,
			$q
			) {

			var update = function () {
				var ItemsHandler = $injector.get('ItemsHandler');

				var d = $q.defer();
				ItemsHandler
					.update(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var create = function () {
				var ItemsHandler = $injector.get('ItemsHandler');

				var d = $q.defer();
				ItemsHandler
					.create(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var remove = function () {
				var ItemsHandler = $injector.get('ItemsHandler');

				var d = $q.defer();
				ItemsHandler
					.remove(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var struct = {
				id: null,
				name: null,
				created_at: null,
				deleted_at: null,
				updated_at: null,
				update: update,
				remove: remove,
				create: create
			};

			return function () {
				return angular.extend({}, struct);
			};
		}
	]);
});
