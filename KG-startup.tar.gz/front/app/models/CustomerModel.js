define([
	'app',
	'handlers/CustomerHandler'
], function (
	app
	) {
	app.factory('CustomerModel', [
		'$injector',
		'$q',
		function (
			$injector,
			$q
			) {

			var update = function () {
				var CustomerHandler = $injector.get('CustomerHandler');

				var d = $q.defer();
				CustomerHandler
					.update(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var create = function () {
				var CustomerHandler = $injector.get('CustomerHandler');

				var d = $q.defer();
				CustomerHandler
					.create(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var remove = function () {
				var CustomerHandler = $injector.get('CustomerHandler');

				var d = $q.defer();
				CustomerHandler
					.remove(this)
					.then(function (r) {
						d.resolve(r);
					}, function (r) {
						d.reject(r);
					});
				return d.promise;
			};

			var struct = {
				id: null,
				name: null,
				created_at: null,
				deleted_at: null,
				updated_at: null,
				update: update,
				remove: remove,
				create: create
			};

			return function () {
				return angular.extend({}, struct);
			};
		}
	]);
});
