define([
	'app',
	'handlers/AuthHandler',
	'handlers/RentItemReturnRecordsHandler',
	'services/AppStorage'
], function (
	app
	) {
	app
		.factory('RentItemReturnRecordModel', [
			'$q',
			'$injector',
			'AuthHandler',
			'AppStorage',
			function (
				$q,
				$injector,
				AuthHandler,
				AppStorage
				) {

				var one = function () {
					var RentItemReturnRecordsHandler = $injector.get('RentItemReturnRecordsHandler');

					var d = $q.defer();

					RentItemReturnRecordsHandler
						.one(this)
						.then(function (a) {
							d.resolve(a);
						}, function (a) {
							d.reject(a);
						});

					return d.promise;
				};
				var create = function () {
					var RentItemReturnRecordsHandler = $injector.get('RentItemReturnRecordsHandler');

					var d = $q.defer();
					RentItemReturnRecordsHandler
						.create(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};
				var update = function () {
					var RentItemReturnRecordsHandler = $injector.get('RentItemReturnRecordsHandler');

					var d = $q.defer();
					RentItemReturnRecordsHandler
						.update(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};
				var calculation = function () {
					var RentItemReturnRecordsHandler = $injector.get('RentItemReturnRecordsHandler');

					var d = $q.defer();
					RentItemReturnRecordsHandler
						.calculation(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};

				var struct = {
					id: null,
					in_draft: null,
					created_at: null,
					one: one,
					create: create,
					update: update,
					calculation: calculation
				};

				return function () {
					return angular.extend({}, struct);
				};
			}
		]);
});
