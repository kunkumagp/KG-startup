define([
	'app',
	'handlers/AuthHandler',
	'exceptions/InvalidInputException',
	'services/AppStorage',
	'handlers/AdminsHandler'
], function (
	app
	) {
	app
		.factory('AdminModel', [
			'$q',
			'$injector',
			'AuthHandler',
			'InvalidInputException',
			'AppStorage',
			function (
				$q,
				$injector,
				AuthHandler,
				InvalidInputException,
				AppStorage
				) {

				var update = function () {
					var AdminsHandler = $injector.get('AdminsHandler');

					var d = $q.defer();
					AdminsHandler
						.update(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};

				var create = function () {
					var AdminsHandler = $injector.get('AdminsHandler');

					var d = $q.defer();
					AdminsHandler
						.create(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};

				var remove = function () {
					var AdminsHandler = $injector.get('AdminsHandler');

					var d = $q.defer();
					AdminsHandler
						.remove(this)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				};

				var setLogged = function () {
					AppStorage.setObject('admin', this);
					AppStorage.setItem('authenticated', true);
				};

				var setLoggedOut = function () {
					AppStorage.removeObject('admin');
					AppStorage.removeItem('authenticated');
				};

				var validateLogin = function (userModel) {
					if (userModel.username.length === 0 || userModel.password.length === 0) {
						throw new InvalidInputException('Please enter credentials to login.');
					}
				};

				var login = function () {
					var d = $q.defer();

					validateLogin(this);

					AuthHandler
						.login(this)
						.then(function (a) {
							d.resolve(a);
						}, function (a) {
							d.reject(a);
						});

					return d.promise;
				};

				var changePassword = function (passwordData) {
					var AdminsHandler = $injector.get('AdminsHandler');

					var d = $q.defer();

					AdminsHandler.changePassword(this, passwordData)
						.then(function (a) {
							d.resolve(a);
						}, function (a) {
							d.reject(a);
						});

					return d.promise;
				};

				var struct = {
					id: null,
					username: null,
					first_name: null,
					last_name: null,
					auth_token: null,
					login: login,
					setLogged: setLogged,
					setLoggedOut: setLoggedOut,
					remove: remove,
					update: update,
					create: create,
					changePassword: changePassword
				};

				return function () {
					return angular.extend({}, struct);
				};
			}
		]);
});
