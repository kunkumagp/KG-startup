define([
	'angular'
], function (
	angular
	) {
	var app = angular.module('app', [
		'ngRoute',
		'ui.router',
		'ui.bootstrap',
		'toastr',
		'validation',
		'validation.rule'
	]);

	app.config([
		'$controllerProvider',
		'$compileProvider',
		'$filterProvider',
		'$provide',
		function (
			$controllerProvider,
			$compileProvider,
			$filterProvider,
			$provide
			) {
			app.controller = $controllerProvider.register;
			app.service = $provide.service;
			app.factory = $provide.factory;
			app.filter = $filterProvider.register;
			app.directive = $compileProvider.directive;
		}
	]);

	app.run(['$rootScope', '$state', function ($rootScope, $state) {

			$rootScope.$on('$stateChangeStart', function (evt, to, params) {
				if (to.redirectTo) {
					evt.preventDefault();
					$state.go(to.redirectTo, params, {location: 'replace'})
				}
			});
		}]);

	return app;
});