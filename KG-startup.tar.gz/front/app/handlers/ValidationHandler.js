define([
    'app'
], function(
    app
) {
    app
        .factory('ValidationHandler', [
            function() {
                return {
                    handleAPIValidation: function(response, errors) {

                        var responseErrors = response.data;
                        var errorsList = "<ul class='list-group'>";

                        for (var i in responseErrors) {
                            if (i in errors) {
                                for (var x = 0; x < responseErrors[i].length; x++) {
                                    if (responseErrors[i][x] in errors[i]) {
                                        errorsList += "<li  class='list-group-item list-group-item-danger'>" + errors[i][responseErrors[i][x]] + "</li>";
                                    }
                                }
                            }
                        }

                        errorsList += "</ul>";
                        return errorsList;
                    }
                };

            }
        ]);
});
