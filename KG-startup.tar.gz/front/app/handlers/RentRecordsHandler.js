define([
	'app',
	'services/csmsAPI',
	'models/RentRecordModel',
	'models/ItemModel',
	'services/AppStorage'
], function (
	app
	) {
	app.factory('RentRecordsHandler', [
		'$q',
		'csmsAPI',
		'RentRecordModel',
		'ItemModel',
		'AppStorage',
		function (
			$q,
			csmsAPI,
			RentRecordModel,
			ItemModel,
			AppStorage
			) {
			return {
				create: function (rentRecords) {
					var d = $q.defer();
					csmsAPI.rentRecords.create(rentRecords)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				all: function () {

					var d = $q.defer();

					csmsAPI.items._()
						.then(function (r) {
							var items = [];

							for (var i = 0; i < r.data.length; i++) {
								var item = new ItemModel();

								item.id = r.data[i].id;
								item.name = r.data[i].name;
								item.created_at = r.data[i].created_at;

								items.push(angular.copy(item));
							}
							d.resolve(items);
						}, function (r) {
							d.reject(r);
						});



					return d.promise;
				}
			};
		}
	]);
});
