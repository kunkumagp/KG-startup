define([
	'app',
	'services/csmsAPI',
	'models/CustomerModel'
], function (
	app
	) {
	app.factory('CustomerHandler', [
		'$q',
		'csmsAPI',
		'CustomerModel',
		function (
			$q,
			csmsAPI,
			CustomerModel
			) {
			return {
				all: function () {
					var d = $q.defer();

					csmsAPI.customers._()
						.then(function (r) {
							var customers = {};

							for (var i = 0; i < r.data.length; i++) {
								var customer = new CustomerModel();

								customer.id = r.data[i].id;
								customer.name = r.data[i].name;
								customer.created_at = r.data[i].created_at;

								customers[customer.id] = customer;
							}
							d.resolve(customers);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				create: function (customer) {
					var d = $q.defer();
					csmsAPI.customers.create(customer)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				remove: function (customer) {
					var d = $q.defer();
					csmsAPI.customers.remove(customer)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				update: function (customer) {
					var d = $q.defer();
					csmsAPI.customers.update(customer)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				}
			};
		}
	]);
});
