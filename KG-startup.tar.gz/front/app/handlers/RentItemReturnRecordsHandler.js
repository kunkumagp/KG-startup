define([
	'app',
	'services/csmsAPI',
	'models/RentItemReturnRecordModel',
	'models/CustomerModel',
	'services/AppStorage'
], function (
	app
	) {
	app.factory('RentItemReturnRecordsHandler', [
		'$q',
		'csmsAPI',
		'RentItemReturnRecordModel',
		'CustomerModel',
		'AppStorage',
		function (
			$q,
			csmsAPI,
			RentItemReturnRecordModel,
			CustomerModel,
			AppStorage
			) {
			return {
				create: function (rentRecords) {
					var d = $q.defer();
					csmsAPI.rentRecords.create(rentRecords)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				all: function () {

					var d = $q.defer();

					csmsAPI.customers._()
						.then(function (r) {
							var customers = [];

							for (var i = 0; i < r.data.length; i++) {
								var customer = new CustomerModel();

								customer.id = r.data[i].id;
								customer.name = r.data[i].name;
								customer.created_at = r.data[i].created_at;

								customers.push(angular.copy(customer));
							}
							d.resolve(customer);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				one: function (rentItemReturnRecord) {
					var d = $q.defer();
					csmsAPI.rentItemReturnRecord._(rentItemReturnRecord)
						.then(function (r) {
							var records = [];
							var total = 0;

							for (var i = 0; i < r.data.length; i++) {
								var record = new RentItemReturnRecordModel();

								if (r.data[i].returned_date === null) {
									record.returned_date = 'Not-returned';
								} else {
									record.returned_date = 'checked';
								}

								record.id = r.data[i].id;
								record.name = r.data[i]['items'].name;
								record.qty = r.data[i].qty;
								record.rented_date = r.data[i].rented_date;
								record.charges = r.data[i].charges;
								total += (record.charges);


								records.push(angular.copy(record));
							}
							records.total = total;
							d.resolve(records);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				calculation: function (customer_id) {
					var d = $q.defer();
					csmsAPI.rentItemReturnRecord.calculation(customer_id)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				totalCalculate: function (price) {
					var d = $q.defer();
					csmsAPI.rentItemReturnRecord.calculation(customer_id)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				
				update: function (rentItemReturnRecordId) {
					var d = $q.defer();
					csmsAPI.rentItemReturnRecord.update(rentItemReturnRecordId)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				}
			};
		}
	]);
});
