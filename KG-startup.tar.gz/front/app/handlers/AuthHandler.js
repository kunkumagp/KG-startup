define([
	'app',
	'services/csmsAPI',
	'services/AppStorage'
], function (
	app
	) {
	app
		.factory('AuthHandler', [
			'$q',
			'csmsAPI',
			'AppStorage',
			'$state',
			function (
				$q,
				csmsAPI,
				AppStorage,
				$state
				) {
				return {
					redirectByAuthenticatedStatus: function (ifAuthenticated, ifUnauthenticated) {
						this.logoutIfSessionExpired();

						if (AppStorage.getItem('authenticated') == "true") {
							$state.go(ifAuthenticated);
						} else {
							$state.go(ifUnauthenticated);
						}

					},
					redirectIfAuthenticated: function (state) {
						if (AppStorage.getItem('authenticated') == "true") {
							$state.go(state);
						}
					},
					redirectIfNotAuthenticated: function (state) {
						if (AppStorage.getItem('authenticated') != "true") {
							$state.go(state);
						}
					},
					logout: function (state) {
						AppStorage.allClear();
						$state.go(state);
					},
					logoutIfSessionExpired: function () {
						var self = this;

						csmsAPI
							.auth
							.validate()
							.then(null, function (r) {
								self.logout('login');
							});
					},
					login: function (loginUser) {
						var d = $q.defer();
						csmsAPI.auth.login(loginUser)
							.then(function (r) {
								var apiUser = r.data;
								delete loginUser.password;
								
								loginUser.id = apiUser.admin.id;
								loginUser.username = apiUser.admin.username;
								loginUser.auth_token = apiUser.auth_token;

								d.resolve(loginUser);
							}, function (r) {
								d.reject(r);
							});

						return d.promise;
					}
				};

			}
		]);
});
