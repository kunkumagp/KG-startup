define([
	'app',
	'services/csmsAPI',
	'models/AdminModel',
	'services/AppStorage'
], function (
	app
	) {
	app.factory('AdminsHandler', [
		'$q',
		'csmsAPI',
		'AdminModel',
		'AppStorage',
		function ($q, csmsAPI, AdminModel, AppStorage) {
			return {
				all: function () {
					var d = $q.defer();

					csmsAPI.admins._()
						.then(function (r) {
							var admins = {};

							for (var i = 0; i < r.data.length; i++) {
								var admin = new AdminModel();

								admin.id = r.data[i].id;
								admin.username = r.data[i].username;
								admin.created_at = r.data[i].created_at;

								admins[admin.id] = admin;
							}
							d.resolve(admins);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				create: function (admin) {
					var d = $q.defer();
					csmsAPI.admins.create(admin)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				update: function (admin) {
					var d = $q.defer();
					csmsAPI.admins.update(admin)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				},
				remove: function (admin) {
					var d = $q.defer();
					csmsAPI.admins.remove(admin)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				current: function () {
					var admin = new AdminModel();
					var localAdmin = AppStorage.getObject('admin');

					admin.id = localAdmin.id;
					admin.username = localAdmin.username;
					admin.first_name = localAdmin.first_name;
					admin.last_name = localAdmin.last_name;
					admin.auth_token = localAdmin.auth_token;
					admin.created_at = localAdmin.created_at;
					admin.deleted_at = localAdmin.deleted_at;
					admin.updated_at = localAdmin.updated_at;

					return admin;
				},
				changePassword: function (admin) {
					var d = $q.defer();
					csmsAPI.admins.changePassword(admin)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});
					return d.promise;
				}
			};
		}
	]);
});
