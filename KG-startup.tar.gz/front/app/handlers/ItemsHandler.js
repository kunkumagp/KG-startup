define([
	'app',
	'services/csmsAPI',
	'models/ItemModel'
], function (
	app
	) {
	app.factory('ItemsHandler', [
		'$q',
		'csmsAPI',
		'ItemModel',
		function (
			$q,
			csmsAPI,
			ItemModel
			) {
			return {
				all: function () {
					var d = $q.defer();

					csmsAPI.items._()
						.then(function (r) {
							var items = {};

							for (var i = 0; i < r.data.length; i++) {
								var item = new ItemModel();

								item.id = r.data[i].id;
								item.name = r.data[i].name;
								item.created_at = r.data[i].created_at;

								items[item.id] = item;
							}
							d.resolve(items);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				create: function (item) {
					var d = $q.defer();
					csmsAPI.items.create(item)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				remove: function (item) {
					var d = $q.defer();
					csmsAPI.items.remove(item)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				},
				update: function (item) {
					var d = $q.defer();
					csmsAPI.items.update(item)
						.then(function (r) {
							d.resolve(r);
						}, function (r) {
							d.reject(r);
						});

					return d.promise;
				}
			};
		}
	]);
});
