define([
	'app'
], function (
	app
	) {
	app.config([
		'$urlRouterProvider',
		'$injector',
		'$locationProvider',
		function (
			$urlRouterProvider,
			$injector,
			$locationProvider
			) {
			$urlRouterProvider.otherwise('/');

			$urlRouterProvider.rule(function ($injector, $location) {
				var path = $location.url();
				if (path[path.length - 1] === '/' || path.indexOf('/?') > -1) {
					return;
				}
				if (path.indexOf('?') > -1) {
					return path.replace('?', '/?');
				}
				return path + '/';
			});

			$locationProvider.html5Mode(true);
		}
	]);
});
