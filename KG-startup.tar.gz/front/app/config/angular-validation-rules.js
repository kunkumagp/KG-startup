define([
	'app'
], function (
	app
	) {
	app.config([
		'$validationProvider',
		function (
			$validationProvider
			) {
			$validationProvider
				.setExpression({
					confirmPassword: function (value, scope, element, attrs) {
						return value === attrs.matchPassword;
					},
					negativeNumber: function (value) {
						var regex = /^[\d|null]*$/;
						return regex.test(value);
					},
					nullOrEmail: function (value) {
						var regex = /^[\d|null]|(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
						return regex.test(value);
					},
					email: function (value) {
						var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
						return regex.test(value);
					},
					phone: function (value) {
						var regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
						return regex.test(value);
					}
				})
				.setDefaultMsg({
					confirmPassword: {
						error: '<div class="text-red">Please provide matching password</div>',
						success: 'Confirmed!'
					},
					negativeNumber: {
						error: 'Please provide a valid quantity',
						success: 'Confirmed!'
					},
					nullOrEmail: {
						error: 'Please provide a valid email',
						success: 'Confirmed!'
					},
					phone: {
						error: 'Please provide a valid phone number',
						success: 'Success '
					},
					email: {
						error: '<div class="text-red">Please provide a valid email</div>',
						success: 'It\'s Email'
					},
					required: {
						error: '<div class="text-red">Required</div>',
						success: 'Success '
					},
				});

			$validationProvider.showSuccessMessage = false;
		}
	]);
});