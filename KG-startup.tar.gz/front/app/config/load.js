define([
	'config/routes',
	'config/angular-validation-rules'
]);