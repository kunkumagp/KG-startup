define([
	'config/load',
	'routes/load'
]);