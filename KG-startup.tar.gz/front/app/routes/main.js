define([
	'app'
], function (
	app
	) {
	app.config([
		'$stateProvider',
		function (
			$stateProvider
			) {
			$stateProvider
				.state('main', {
					url: '/',
					redirectTo: 'home',
				})
				.state('home', {
					url: '/home/',
					templateUrl: 'app/views/dashboard.html',
					controller: 'HomeController',
					resolve: {
						controller: function ($q) {
							var deferred = $q.defer();
							require(['controllers/HomeController'], function () {
								deferred.resolve();
							});
							return deferred.promise;
						}
					}
				})
				.state('login', {
					url: '/login/',
					templateUrl: 'app/views/login.html',
					controller: 'LoginController',
					resolve: {
						controller: function ($q) {
							var deferred = $q.defer();
							require(['controllers/LoginController'], function () {
								deferred.resolve();
							});
							return deferred.promise;
						}
					}
				});
		}
	]);
});