define([
	'routes/main'
]);